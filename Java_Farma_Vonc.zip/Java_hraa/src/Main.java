
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main (String [] args){
        Scanner auto= new Scanner(System.in);
            System.out.println("Vítejte na farmě");
        System.out.println("Zadejte název zvířete, u kterého chcete vidět vlastnosti");
        int uzivatel = auto.nextInt();
        System.out.println("Vybrali jste" + uzivatel);
    }
    public static Random scanner;
    public class animal {
    {
        Scanner autom = new Scanner(System.in);
        for (int zvire = 1; zvire >= 1; zvire++) {
            System.out.println("Vítejte na farmě!");

            System.out.println("Zadejte název zvířete, u kterého chcete vidět vlastnosti");
            int uziv = scanner.nextInt();
            System.out.println("Vybrali jste" + uziv);
            while (2 >= 1) {
                uziv = autom.nextInt();
                switch (uziv) {
                    case 1:
                        System.out.println("Vybrali jste " + pes);
                        break;
                    case 2:
                        System.out.println("Vybrali jste" + kočka);
                        break;
                    case 3:
                        System.out.println("Vybrali jste" + osel);
                        break;
                    case 4:
                        System.out.println("Vybrali jste" + kůň);
                        break;
                    case 5:
                        System.out.println("Vybrali jste" + kráva);
                        break;
                    case 6:
                        System.out.println("Vybrali jste" + slepice);
                        break;
                    case 7:
                        System.out.println("Vybrali jste" + ovce);
                        break;
                    case 8:
                        System.out.println("Vybrali jste" + koza);
                        break;
                    default:
                        System.out.println("Nevybrali jste si vhodné zvíře");
                }
            }
                            }
        }

        }
    class animals {
        public static void main(String[] args) {
            String název;
            int věk;
            String typ;
            String barva;
            int uziv = scanner.nextInt();
            switch(uziv){

                case 1: System.out.println("Vybrali jste");
                    break;
                case 2: System.out.println("Vybrali jste");
                    break;
                case 3: System.out.println("Vybrali jste");
                    break;
                //Default case statement
                default:System.out.println("Not in 10, 20 or 30");

            }
        }
    }
    int pes;
    int kočka;
    int kráva;
    int osel;
    int kůň;
    int slepice;
    int ovce;
    int koza;


    public int get_kočka() {
        return kočka;
    }

    public int get_pes() {
        return pes;
    }

    public int get_kráva() {
        return kráva;
    }

    public int get_kůň() {
        return kůň;
    }

    public int get_osel() {
        return osel;
    }

    }
