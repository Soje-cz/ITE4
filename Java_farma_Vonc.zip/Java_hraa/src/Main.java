
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main (String [] args){
        Scanner auto= new Scanner(System.in);
            System.out.println("Vítejte na farmě");
        System.out.println("Zadejte název zvířete, u kterého chcete vidět vlastnosti");
        int uzivatel = auto.nextInt();
        System.out.println("Vybrali jste" + auto);

    }
    public static Random scanner;
    public class animal {
    {
        for (int zvire = 1; zvire >= 2; zvire++) {
            System.out.println("Vítejte na farmě!");
            System.out.println("Zadejte název zvířete, u kterého chcete vidět vlastnosti");
            int uziv = scanner.nextInt();
            System.out.println("Vybrali jste" + scanner);
            while (2 >= 1) {
                uziv = scanner.nextInt();
            }
        }
    }
        public class animals {
            ArrayList<String> animals = new ArrayList<String>();
    /*animals.add("pes");
    animals.add("kočka");
    animals.add("kráva");
    animals.add("osel");
    animals.add("kůň")

     */
        }
    int pes;
    int kočka;
    int kráva;
    int osel;
    int kůň;

    public int get_kočka() {
        return kočka;
    }

    public int get_pes() {
        return pes;
    }

    public int get_kráva() {
        return kráva;
    }

    public int get_kůň() {
        return kůň;
    }

    public int get_osel() {
        return osel;
    }
    }
    @Override
    public String toString() {
        return super.toString();
    }

    }
